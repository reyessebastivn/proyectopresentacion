package com.example.api_perfume;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiPerfumeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiPerfumeApplication.class, args);
	}

}
