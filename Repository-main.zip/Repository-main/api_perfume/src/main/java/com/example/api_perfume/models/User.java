package com.example.api_perfume.models;

import lombok.Data;

@Data
public class User {
    private String id;
    private String email;
    private String nombre;
}