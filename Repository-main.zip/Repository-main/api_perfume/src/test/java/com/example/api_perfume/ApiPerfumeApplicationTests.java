package com.example.api_perfume;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiPerfumeApplicationTests {

	@Test
	void contextLoads() {
	}

}
