package com.example.api_ventas_inventario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiVentasInventarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
